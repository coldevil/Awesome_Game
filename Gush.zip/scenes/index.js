import "/scenes/intro.js";
import "/scenes/title-screen.js";
import "/scenes/character-select.js";
import "/scenes/main.js";
import "/scenes/gameover.js";